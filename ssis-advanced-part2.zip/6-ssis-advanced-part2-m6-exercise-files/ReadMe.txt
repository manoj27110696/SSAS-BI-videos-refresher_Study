Special Design Scenarios
Advanced Integration Services Part 2
Stacia Misner
www.pluralsight.com


1. You must install SQL Server Data Tools for Visual Studio 2012 and SQL Server 2014 Integration Services. 

2. Open SQL Server Data Tools. Click File, Open, and then Project/Solution. Navigate to the before or after folder for this module and then double-click the ssis-adv-2-m1.SLN file in that folder to work with the module�s demo files.  

3. Extract the ssis-adv-data-2.zip file to the C:\ drive.
