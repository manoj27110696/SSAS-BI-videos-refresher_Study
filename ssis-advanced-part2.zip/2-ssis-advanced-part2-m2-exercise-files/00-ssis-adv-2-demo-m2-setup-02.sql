--00-ssis-adv-2-demo-m2-setup-02.sql
--connect to master

CREATE DATABASE [AzureAdventureWorksDW]

GO


