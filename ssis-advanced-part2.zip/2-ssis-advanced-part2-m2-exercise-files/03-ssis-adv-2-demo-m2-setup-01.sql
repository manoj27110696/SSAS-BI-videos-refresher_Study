--03-ssis-adv-2-demo-m2-setup-01.sql
--connect to master

drop database [AzureAdventureWorksDW]
go

CREATE DATABASE [AzureAdventureWorksDW]

GO



