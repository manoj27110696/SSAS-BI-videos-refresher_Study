Deployment Part 2
Advanced Integration Services Part 2
Stacia Misner
www.pluralsight.com


The demonstrations in this module assume that you have installed the AdventureWorks2012 and AdventureWorksDW2012 databases in a local SQL Server 2012 database instance. You can download the respective data files from http://msftdbprodsamples.codeplex.com/releases/view/55330. The Release Notes on the page with the data files includes links to instructions for installing the data files. 

Extract the etl.zip file in the /before folder to work with the Deploying a Project from an ISPAC file demonstration.

Note: The packages in the demonstration file require SQL Server 2012 or SQL Server 2014. 

