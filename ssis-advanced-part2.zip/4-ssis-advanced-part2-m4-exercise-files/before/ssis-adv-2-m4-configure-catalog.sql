exec [SSISDB].[catalog].[configure_catalog]
@property_name=N'MAX_PROJECT_VERSIONS',
@property_value=N'12'